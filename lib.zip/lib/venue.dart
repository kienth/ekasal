import 'package:flutter/material.dart';

import 'menu.dart';

class HomePage extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyVenuePage(),
    );
  }
}

class MyVenuePage extends StatefulWidget {
  static String tag = 'login-page';
  String get title => 'E - Kasal';
  @override
  _MyVenuePageState createState() => _MyVenuePageState();
}

class _MyVenuePageState extends State<MyVenuePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Color(0xff08aafc),
      ),
      body: Container(
        width: double.infinity,
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 20.0,
                      right: 5.0,
                      top: 10.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyMenuPage()));
                      },
                      child: new Container(
                          alignment: Alignment.topLeft,
                          height: 60.0,
                          child: new Text(
                            "Venue:   cove",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black),
                          )),
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 10.0,
                      right: 10.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyMenuPage()));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 215.0,
                          child: Image.asset('assets/icon/venue.png'),
                          decoration: new BoxDecoration(
                            border: Border.all(),
                          ),
                          
                          ),
                    ),
                  ),
                ),
              ],
            ),
            
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: Colors.lightBlue,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), 
    );
  }
}
