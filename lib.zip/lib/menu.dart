import 'package:flutter/material.dart';
import 'package:hello_world/table.dart';
import 'package:hello_world/venue.dart';
import 'table.dart';

class MenuPage extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyMenuPage(),
    );
  }
}

class MyMenuPage extends StatefulWidget {
  static String tag = 'login-page';
  String get title => 'E-Kasal';
  @override
  _MyMenuPageState createState() => _MyMenuPageState();
}

class _MyMenuPageState extends State<MyMenuPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Color(0xff08aafc),
      ),
      body: Container(
        width: double.infinity,
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 5.0,
                      top: 10.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                            // borderRadius: new BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                          ),
                          child: new Text(
                            "Jeffrey Paclar & Leslie Patana",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 100.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "Checklist",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (context) => MyVenuePage()
                        ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 100.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "Venue",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (context) => MyTablePage()
                        ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 100.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "Budget / remaining budget",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
