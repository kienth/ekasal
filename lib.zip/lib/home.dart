import 'package:flutter/material.dart';

import 'menu.dart';

class HomePage extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  static String tag = 'login-page';
  String get title => 'E - Kasal';
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Color(0xff08aafc),
      ),
      body: Container(
        width: double.infinity,
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 20.0,
                      right: 5.0,
                      top: 40.0,
                    ),
                    child: GestureDetector(                      
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyMenuPage()));
                      },
                      child: Container(
                          alignment: Alignment.center,
                          height: 60.0,
                          decoration: BoxDecoration(
                            color: Color(0xff95d6f7),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: new Text(
                            "Jeffrey Paclar & Leslie Patana",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )),
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 20.0,
                      right: 5.0,
                      top: 40.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MyMenuPage()));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 60.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            borderRadius: new BorderRadius.circular(10.0),
                          ),
                          child: new Text(
                            "Kienth James Acenas & Valerie Mae Vitorillo",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )),
                    ),
                  ),
                ),
              ],
            ),
            
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: Colors.lightBlue,
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), 
    );
  }
}
