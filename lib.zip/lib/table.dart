import 'package:flutter/material.dart';

class TablePage extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyTablePage(),
    );
  }
}

class MyTablePage extends StatefulWidget {
  static String tag = 'login-page';
  String get title => 'E-Kasal';
  @override
  _MyTablePageState createState() => _MyTablePageState();
}

class _MyTablePageState extends State<MyTablePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Color(0xff08aafc),
      ),
      body: Container(
        width: double.infinity,
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 5.0,
                      top: 10.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                            // borderRadius: new BorderRadius.only(topLeft: Radius.circular(10.0), topRight: Radius.circular(10.0)),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "Gown",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),
            new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "Ring",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),new Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.centerLeft,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 0.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 0.0,
                      right: 5.0,
                      top: 0.0,
                    ),
                    child: GestureDetector(
                      onTap: () {
                        // Navigator.push(context, MaterialPageRoute(
                        //   builder: (context) => MyHomePage()
                        // ));
                      },
                      child: new Container(
                          alignment: Alignment.center,
                          height: 40.0,
                          decoration: new BoxDecoration(
                            color: Color(0xff95d6f7),
                            border: new Border.all(),
                          ),
                          child: new Text(
                            "",
                            style: new TextStyle(
                                fontSize: 20.0, color: Colors.black45),
                          )), 
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
