import 'package:flutter/material.dart';
import 'login.dart';
// import 'package:flutter/semantics.dart';
// import 'package:hello_world/main_1.dart';

void main() => runApp(ekasal());



class ekasal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ekasal',
      debugShowCheckedModeBanner: false,
      // theme: ThemeData(fontFamily: 'Roboto'),
      home: LoginPage(),
    );
  }
}
